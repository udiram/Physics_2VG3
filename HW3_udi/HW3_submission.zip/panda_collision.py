from __future__ import annotations

import math
from typing import Iterable

from panda3d.core import NodePath, Vec3


class Particle(NodePath):
    def __init__(
        self,
        loader,
        parent: NodePath,
        pos: Vec3,
        vel: Vec3,
        inverseMass: float = 1.0,
        radius: float = 1.0,
        color: tuple[float, float, float, float] = (1.0, 1.0, 1.0, 1.0),
        name: str = "particle",
    ) -> None:
        super().__init__(name)
        self.reparentTo(parent)

        visual = loader.loadModel("models/misc/sphere")
        visual.reparentTo(self)
        self.setScale(radius)
        self.setColor(*color)
        self.setPos(pos)

        self.vel = Vec3(vel)
        self.inverseMass = inverseMass
        self.radius = radius

    @property
    def mass(self) -> float:
        return float("inf") if self.inverseMass == 0.0 else 1.0 / self.inverseMass


class CollisionWorld:
    def __init__(self, particles: Iterable[Particle], restitution: float = 1.0, substeps: int = 4, solver_iterations: int = 4):
        self.particles = list(particles)
        self.restitution = restitution
        self.substeps = max(1, substeps)
        self.solver_iterations = max(1, solver_iterations)
        self.time = 0.0
        self.collision_count = 0

    def step(self, dt: float) -> int:
        hits = 0
        sub_dt = dt / float(self.substeps)

        for _ in range(self.substeps):
            hits += self._integrate_substep(sub_dt)

        self.time += dt
        return hits

    def _integrate_substep(self, dt: float) -> int:
        # Continuous sphere-sphere collision handling for this interval.
        remaining = dt
        hits = 0
        eps = 1e-8
        max_events = max(16, len(self.particles) * 4)
        events = 0

        while remaining > eps and events < max_events:
            hit_time, hit_pairs = self._find_earliest_impact(remaining)
            self._advance_all(hit_time)
            remaining -= hit_time

            if not hit_pairs:
                break

            counted: set[tuple[int, int]] = set()
            for _ in range(self.solver_iterations):
                changed = False
                for i, j in hit_pairs:
                    if self._resolve_pair(self.particles[i], self.particles[j]):
                        changed = True
                        key = (i, j)
                        if key not in counted:
                            counted.add(key)
                            hits += 1
                            self.collision_count += 1
                if not changed:
                    break

            events += 1

            # Prevent stalling on numerically repeated t=0 impacts.
            if hit_time <= eps and not counted and remaining > eps:
                nudge = min(remaining, 1e-6)
                self._advance_all(nudge)
                remaining -= nudge

        if remaining > eps:
            self._advance_all(remaining)

        return hits

    def _advance_all(self, dt: float) -> None:
        if dt <= 0.0:
            return
        for particle in self.particles:
            particle.setPos(particle.getPos() + particle.vel * dt)

    def _find_earliest_impact(self, max_t: float) -> tuple[float, list[tuple[int, int]]]:
        toi_eps = 1e-7
        earliest = max_t
        pairs: list[tuple[int, int]] = []

        for i in range(len(self.particles)):
            for j in range(i + 1, len(self.particles)):
                toi = self._time_of_impact(self.particles[i], self.particles[j], max_t)
                if toi is None:
                    continue
                if toi < earliest - toi_eps:
                    earliest = toi
                    pairs = [(i, j)]
                elif abs(toi - earliest) <= toi_eps:
                    pairs.append((i, j))

        if not pairs:
            return max_t, []
        return earliest, pairs

    def _time_of_impact(self, a: Particle, b: Particle, max_t: float) -> float | None:
        rel_pos = b.getPos() - a.getPos()
        rel_vel = b.vel - a.vel
        target = a.radius + b.radius
        target_sq = target * target

        c = rel_pos.dot(rel_pos) - target_sq
        if c <= 1e-8:
            return 0.0

        aa = rel_vel.dot(rel_vel)
        if aa <= 1e-12:
            return None

        bb = 2.0 * rel_pos.dot(rel_vel)
        if bb >= 0.0:
            return None

        disc = bb * bb - 4.0 * aa * c
        if disc < 0.0:
            return None

        t = (-bb - math.sqrt(disc)) / (2.0 * aa)
        if t < -1e-8 or t > max_t + 1e-8:
            return None
        return max(0.0, min(max_t, t))

    def calculateConservation(self, about: Vec3 = Vec3(0.0, 0.0, 0.0), include_infinite: bool = False) -> dict:
        p_total = Vec3(0.0, 0.0, 0.0)
        l_total = Vec3(0.0, 0.0, 0.0)
        k_total = 0.0

        for particle in self.particles:
            if particle.inverseMass == 0.0 and not include_infinite:
                continue
            mass = particle.mass
            momentum = particle.vel * mass
            p_total += momentum
            r = particle.getPos() - about
            l_total += r.cross(momentum)
            k_total += 0.5 * mass * particle.vel.dot(particle.vel)

        out = {
            "time": self.time,
            "P": p_total,
            "L": l_total,
            "K": k_total,
            "collisions": self.collision_count,
        }

        print(f"t={out['time']}")
        print(f"  linear momentum P = {out['P']}")
        print(f"  angular momentum L = {out['L']}")
        print(f"  kinetic energy K = {out['K']}")
        print(f"  total collisions so far = {out['collisions']}")

        return out

    def bounce_in_box(self, particle: Particle, min_corner: Vec3, max_corner: Vec3) -> None:
        pos = particle.getPos()

        if pos.x - particle.radius < min_corner.x:
            pos.x = min_corner.x + particle.radius
            particle.vel.x *= -1.0
        elif pos.x + particle.radius > max_corner.x:
            pos.x = max_corner.x - particle.radius
            particle.vel.x *= -1.0

        if pos.y - particle.radius < min_corner.y:
            pos.y = min_corner.y + particle.radius
            particle.vel.y *= -1.0
        elif pos.y + particle.radius > max_corner.y:
            pos.y = max_corner.y - particle.radius
            particle.vel.y *= -1.0

        if pos.z - particle.radius < min_corner.z:
            pos.z = min_corner.z + particle.radius
            particle.vel.z *= -1.0
        elif pos.z + particle.radius > max_corner.z:
            pos.z = max_corner.z - particle.radius
            particle.vel.z *= -1.0

        particle.setPos(pos)

    def _resolve_pair(self, a: Particle, b: Particle) -> bool:
        delta = b.getPos() - a.getPos()
        min_dist = a.radius + b.radius
        dist_sq = delta.dot(delta)
        tol = 1e-6

        if dist_sq > (min_dist + tol) * (min_dist + tol):
            return False

        dist = dist_sq ** 0.5
        if dist > 1e-10:
            normal = delta / dist
            penetration = min_dist - dist
        else:
            rel = b.vel - a.vel
            if rel.lengthSquared() > 1e-12:
                normal = rel.normalized()
            else:
                normal = Vec3(1.0, 0.0, 0.0)
            penetration = min_dist

        inv_mass_sum = a.inverseMass + b.inverseMass
        if inv_mass_sum <= 0.0:
            return False

        # Separate first to avoid persistent interpenetration.
        if penetration > 0.0:
            correction = normal * (penetration / inv_mass_sum)
            a.setPos(a.getPos() - correction * a.inverseMass)
            b.setPos(b.getPos() + correction * b.inverseMass)

        rel_vel = b.vel - a.vel
        vel_along_normal = rel_vel.dot(normal)

        if vel_along_normal >= -1e-9:
            return False

        impulse_mag = -(1.0 + self.restitution) * vel_along_normal / inv_mass_sum
        impulse = normal * impulse_mag

        a.vel -= impulse * a.inverseMass
        b.vel += impulse * b.inverseMass
        return True
